# Roadmap
- [x] Username entry, fetch last 10 chess.com games
- [x] In-browser Stockfish analysis (accuracy, blunders)
- [x] Report card: openings, tactics, endgames, time
- [x] Replay board with eval bar + graph
- [x] Puzzle set from your blunders
