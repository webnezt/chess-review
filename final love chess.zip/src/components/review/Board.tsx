import { Chess } from "chess.js";
import { useEffect, useMemo, useState } from "react";
import { cn } from "@/lib/utils";

const GLYPH: Record<string, string> = { k: "♚", q: "♛", r: "♜", b: "♝", n: "♞", p: "♟" };
const FILES = "abcdefgh";

type Props = {
  fen: string;
  orientation?: "w" | "b";
  lastMove?: string | null;
  bestMove?: string | null;
  onMove?: (from: string, to: string) => void;
};

export function Board({ fen, orientation = "w", lastMove, bestMove, onMove }: Props) {
  const [sel, setSel] = useState<string | null>(null);
  const chess = useMemo(() => new Chess(fen), [fen]);
  useEffect(() => setSel(null), [fen]);
  const board = chess.board();
  const idx = [0, 1, 2, 3, 4, 5, 6, 7];
  const rows = orientation === "w" ? idx : [...idx].reverse();
  const cols = orientation === "w" ? idx : [...idx].reverse();
  const targets = sel ? chess.moves({ square: sel as never, verbose: true }).map((m) => m.to as string) : [];

  const click = (sq: string) => {
    if (!onMove) return;
    if (sel && targets.includes(sq)) {
      onMove(sel, sq);
      setSel(null);
      return;
    }
    const p = chess.get(sq as never);
    setSel(p && p.color === chess.turn() ? sq : null);
  };

  return (
    <div className="@container grid aspect-square w-full grid-cols-8 grid-rows-[repeat(8,minmax(0,1fr))] overflow-hidden rounded-md shadow-board">
      {rows.map((r) =>
        cols.map((c) => {
          const sq = FILES[c] + (8 - r);
          const p = board[r][c];
          const light = (r + c) % 2 === 0;
          const isLast = lastMove && (lastMove.slice(0, 2) === sq || lastMove.slice(2, 4) === sq);
          const isBest = bestMove && (bestMove.slice(0, 2) === sq || bestMove.slice(2, 4) === sq);
          return (
            <button
              key={sq}
              type="button"
              onClick={() => click(sq)}
              className={cn(
                "relative flex items-center justify-center select-none",
                light ? "bg-board-light" : "bg-board-dark",
                onMove ? "cursor-pointer" : "cursor-default",
              )}
            >
              {isLast && <span className="absolute inset-0 bg-hl-move" />}
              {isBest && <span className="absolute inset-0 bg-hl-best" />}
              {sel === sq && <span className="absolute inset-0 bg-hl-select" />}
              {targets.includes(sq) && (
                <span className="absolute h-1/4 w-1/4 rounded-full bg-hl-target" />
              )}
              {c === cols[0] && (
                <span className="absolute left-0.5 top-0 font-mono text-[9px] text-board-coord">{8 - r}</span>
              )}
              {r === rows[7] && (
                <span className="absolute bottom-0 right-1 font-mono text-[9px] text-board-coord">{FILES[c]}</span>
              )}
              {p && (
                <span className={cn("piece relative text-[10.5cqw] leading-none", p.color === "w" ? "piece-w" : "piece-b")}>
                  {GLYPH[p.type]}
                  {"\uFE0E"}
                </span>
              )}
            </button>
          );
        }),
      )}
    </div>
  );
}
