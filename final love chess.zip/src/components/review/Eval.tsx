import type { Eval } from "@/lib/engine";
import type { MoveReview } from "@/lib/review";
import { winPct } from "@/lib/review";

export const fmtEval = (e: Eval) =>
  e.mate != null ? `M${Math.abs(e.mate)}` : (e.cp > 0 ? "+" : "") + (e.cp / 100).toFixed(1);

export function EvalBar({ ev, orientation }: { ev: Eval; orientation: "w" | "b" }) {
  const white = Math.max(3, Math.min(97, winPct(Math.max(-1500, Math.min(1500, ev.cp)))));
  return (
    <div className={`relative flex w-6 overflow-hidden rounded-sm bg-eval-black ${orientation === "w" ? "flex-col-reverse" : "flex-col"}`}>
      <div className="bg-eval-white transition-all duration-500" style={{ height: `${white}%` }} />
      <span className="absolute left-0 right-0 top-1/2 -translate-y-1/2 text-center font-mono text-[9px] text-muted-foreground mix-blend-difference">
        {fmtEval(ev)}
      </span>
    </div>
  );
}

export function EvalGraph({ moves, current, onSelect }: { moves: MoveReview[]; current: number; onSelect: (i: number) => void }) {
  const n = moves.length;
  const pts = moves.map((m, i) => `${i},${100 - winPct(Math.max(-1500, Math.min(1500, m.evalAfter.cp)))}`);
  const path = `M0,100 L0,50 ${pts.map((p) => "L" + p).join(" ")} L${n - 1},100 Z`;
  return (
    <div className="relative h-24 w-full overflow-hidden rounded-md bg-eval-black">
      <svg viewBox={`0 0 ${Math.max(1, n - 1)} 100`} preserveAspectRatio="none" className="absolute inset-0 h-full w-full">
        <path d={path} className="fill-eval-white" />
        <line x1="0" x2={n} y1="50" y2="50" className="stroke-border" strokeWidth="0.5" vectorEffect="non-scaling-stroke" />
        {current >= 0 && (
          <line x1={current} x2={current} y1="0" y2="100" className="stroke-primary" strokeWidth="2" vectorEffect="non-scaling-stroke" />
        )}
      </svg>
      <div className="absolute inset-0 flex">
        {moves.map((m, i) => (
          <button key={i} type="button" onClick={() => onSelect(i)} className="relative h-full flex-1" aria-label={`Move ${i + 1}`}>
            {(m.cls === "blunder" || m.cls === "mistake") && (
              <span className={`absolute left-1/2 top-1 h-2 w-2 -translate-x-1/2 rounded-full ${m.cls === "blunder" ? "bg-blunder" : "bg-mistake"}`} />
            )}
          </button>
        ))}
      </div>
    </div>
  );
}
