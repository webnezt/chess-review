import { useEffect, useState } from "react";
import { ArrowLeft, ChevronLeft, ChevronRight, ChevronsLeft, ChevronsRight, ExternalLink, Lightbulb } from "lucide-react";
import type { GameReview, Cls } from "@/lib/review";
import { Board } from "./Board";
import { EvalBar, EvalGraph, fmtEval } from "./Eval";
import { cn } from "@/lib/utils";

export const CLS_LABEL: Record<Cls, string> = {
  best: "Best move",
  good: "Good",
  inaccuracy: "Inaccuracy",
  mistake: "Mistake",
  blunder: "Blunder",
};
export const CLS_TEXT: Record<Cls, string> = {
  best: "text-best",
  good: "text-muted-foreground",
  inaccuracy: "text-inaccuracy",
  mistake: "text-mistake",
  blunder: "text-blunder",
};
const SYM: Partial<Record<Cls, string>> = { inaccuracy: "?!", mistake: "?", blunder: "??", best: "★" };

export function GameViewer({ game, onBack }: { game: GameReview; onBack: () => void }) {
  const [idx, setIdx] = useState(-1);
  const [showBest, setShowBest] = useState(false);
  const moves = game.moves;
  const go = (i: number) => {
    setShowBest(false);
    setIdx(Math.max(-1, Math.min(moves.length - 1, i)));
  };
  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      if (e.key === "ArrowRight") go(idx + 1);
      if (e.key === "ArrowLeft") go(idx - 1);
    };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  });

  const cur = idx >= 0 ? moves[idx] : null;
  const fen = cur ? (showBest ? cur.fenBefore : cur.fenAfter) : moves[0].fenBefore;
  const ev = cur ? (showBest ? cur.evalBefore : cur.evalAfter) : moves[0].evalBefore;
  const top = game.userColor === "w" ? game.black : game.white;
  const bottom = game.userColor === "w" ? game.white : game.black;

  return (
    <div className="animate-in fade-in slide-in-from-bottom-2 space-y-4">
      <div className="flex items-center justify-between">
        <button onClick={onBack} className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground">
          <ArrowLeft className="h-4 w-4" /> All games
        </button>
        <a href={game.url} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
          Open on chess.com <ExternalLink className="h-3 w-3" />
        </a>
      </div>
      <div className="grid gap-6 lg:grid-cols-[minmax(0,560px)_1fr]">
        <div className="space-y-2">
          <PlayerRow p={top} />
          <div className="flex gap-2">
            <EvalBar ev={ev} orientation={game.userColor} />
            <div className="flex-1">
              <Board
                fen={fen}
                orientation={game.userColor}
                lastMove={showBest ? null : cur?.uci}
                bestMove={showBest ? cur?.evalBefore.best : null}
              />
            </div>
          </div>
          <PlayerRow p={bottom} />
          <div className="flex justify-center gap-1 pt-2">
            {[
              [ChevronsLeft, -1],
              [ChevronLeft, idx - 1],
              [ChevronRight, idx + 1],
              [ChevronsRight, moves.length - 1],
            ].map(([Icon, to], i) => {
              const I = Icon as typeof ChevronLeft;
              return (
                <button key={i} onClick={() => go(to as number)} className="rounded-md bg-secondary p-2 text-secondary-foreground hover:bg-accent">
                  <I className="h-5 w-5" />
                </button>
              );
            })}
          </div>
        </div>

        <div className="space-y-4">
          <div className="panel p-4">
            <p className="font-mono text-xs uppercase tracking-widest text-muted-foreground">{game.opening}</p>
            {cur ? (
              <div className="mt-2 space-y-2">
                <p className="text-lg">
                  <span className="font-mono text-muted-foreground">{Math.floor(cur.ply / 2) + 1}{cur.color === "w" ? "." : "…"}</span>{" "}
                  <span className="font-semibold">{cur.san}</span>{" "}
                  <span className={cn("font-semibold", CLS_TEXT[cur.cls])}>— {CLS_LABEL[cur.cls]}</span>
                </p>
                <p className="text-sm text-muted-foreground">
                  Eval {fmtEval(cur.evalAfter)} · {cur.phase}
                  {cur.timeSpent != null && ` · ${cur.timeSpent.toFixed(1)}s spent`}
                  {cur.clock != null && ` · ${Math.floor(cur.clock / 60)}:${String(Math.floor(cur.clock % 60)).padStart(2, "0")} left`}
                </p>
                {cur.cls !== "best" && cur.bestSan && (
                  <button
                    onClick={() => setShowBest((s) => !s)}
                    className="inline-flex items-center gap-2 rounded-md bg-primary/15 px-3 py-1.5 text-sm text-primary hover:bg-primary/25"
                  >
                    <Lightbulb className="h-4 w-4" />
                    {showBest ? "Back to game move" : `Engine preferred ${cur.bestSan}`}
                  </button>
                )}
              </div>
            ) : (
              <p className="mt-2 text-sm text-muted-foreground">Use the arrows or ← → keys to step through the game.</p>
            )}
          </div>
          <EvalGraph moves={moves} current={idx} onSelect={go} />
          <div className="panel max-h-[420px] overflow-y-auto p-2">
            <div className="grid grid-cols-[2.5rem_1fr_1fr] gap-x-1 font-mono text-sm">
              {Array.from({ length: Math.ceil(moves.length / 2) }).map((_, r) => (
                <div key={r} className="contents">
                  <span className="py-1 pl-1 text-muted-foreground">{r + 1}.</span>
                  {[moves[r * 2], moves[r * 2 + 1]].map((m, k) =>
                    m ? (
                      <button
                        key={k}
                        onClick={() => go(m.ply)}
                        className={cn("rounded px-2 py-1 text-left hover:bg-accent", idx === m.ply && "bg-accent", CLS_TEXT[m.cls], m.cls === "good" && "text-foreground")}
                      >
                        {m.san}
                        {SYM[m.cls] && <span className="ml-1 text-xs">{SYM[m.cls]}</span>}
                      </button>
                    ) : (
                      <span key={k} />
                    ),
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function PlayerRow({ p }: { p: { name: string; rating: number } }) {
  return (
    <div className="flex items-center justify-between px-8 text-sm">
      <span className="font-semibold">{p.name}</span>
      <span className="font-mono text-muted-foreground">{p.rating}</span>
    </div>
  );
}
