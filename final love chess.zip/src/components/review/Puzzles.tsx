import { Chess } from "chess.js";
import { useState } from "react";
import { Check, X, ArrowRight, Eye } from "lucide-react";
import type { Puzzle } from "@/lib/report";
import { Board } from "./Board";
import { cn } from "@/lib/utils";

export function Puzzles({ puzzles }: { puzzles: Puzzle[] }) {
  const [i, setI] = useState(0);
  const [state, setState] = useState<"solving" | "correct" | "wrong" | "revealed">("solving");
  const [fen, setFen] = useState<string | null>(null);
  const [solved, setSolved] = useState(0);

  if (!puzzles.length)
    return <div className="panel p-8 text-center text-muted-foreground">No mistakes or blunders found — no puzzles to practice. Nice!</div>;

  const p = puzzles[i % puzzles.length];
  const shown = fen ?? p.fen;

  const onMove = (from: string, to: string) => {
    if (state === "correct" || state === "revealed") return;
    const c = new Chess(p.fen);
    try {
      c.move({ from, to, promotion: "q" });
    } catch {
      return;
    }
    if (from + to === p.best.slice(0, 4)) {
      setFen(c.fen());
      setState("correct");
      setSolved((s) => s + 1);
    } else {
      setState("wrong");
    }
  };
  const reveal = () => {
    const c = new Chess(p.fen);
    c.move({ from: p.best.slice(0, 2), to: p.best.slice(2, 4), promotion: p.best[4] || "q" });
    setFen(c.fen());
    setState("revealed");
  };
  const next = () => {
    setI((x) => x + 1);
    setFen(null);
    setState("solving");
  };

  return (
    <div className="grid gap-6 lg:grid-cols-[minmax(0,520px)_1fr]">
      <Board
        fen={shown}
        orientation={p.color}
        onMove={state === "solving" || state === "wrong" ? onMove : undefined}
        bestMove={state === "correct" || state === "revealed" ? p.best : null}
      />
      <div className="space-y-4">
        <div className="panel p-5">
          <p className="font-mono text-xs uppercase tracking-widest text-muted-foreground">
            Puzzle {(i % puzzles.length) + 1} / {puzzles.length} · solved {solved}
          </p>
          <h3 className="mt-2 font-display text-2xl">Find the best move for {p.color === "w" ? "White" : "Black"}</h3>
          <p className="mt-2 text-sm text-muted-foreground">
            From your game vs {p.opponent} ({p.opening}). You played{" "}
            <span className={cn("font-mono font-semibold", p.cls === "blunder" ? "text-blunder" : "text-mistake")}>{p.playedSan}</span> here.
          </p>
          <div className="mt-4 min-h-10">
            {state === "correct" && (
              <p className="inline-flex items-center gap-2 font-semibold text-best"><Check className="h-5 w-5" /> Correct — {p.bestSan}</p>
            )}
            {state === "wrong" && (
              <p className="inline-flex items-center gap-2 font-semibold text-blunder"><X className="h-5 w-5" /> Not quite. Try again.</p>
            )}
            {state === "revealed" && <p className="font-semibold text-primary">The answer was {p.bestSan}</p>}
          </div>
          <div className="mt-4 flex gap-2">
            {state !== "correct" && state !== "revealed" && (
              <button onClick={reveal} className="inline-flex items-center gap-2 rounded-md bg-secondary px-4 py-2 text-sm hover:bg-accent">
                <Eye className="h-4 w-4" /> Show answer
              </button>
            )}
            <button onClick={next} className="inline-flex items-center gap-2 rounded-md bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground hover:opacity-90">
              Next <ArrowRight className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
