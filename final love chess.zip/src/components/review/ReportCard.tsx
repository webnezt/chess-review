import type { buildReport } from "@/lib/report";
import { grade } from "@/lib/report";
import type { GameReview } from "@/lib/review";
import { cn } from "@/lib/utils";

type Report = ReturnType<typeof buildReport>;

const gradeColor = (g: string) =>
  g === "A" ? "text-best" : g === "B" ? "text-primary" : g === "C" ? "text-inaccuracy" : g === "–" ? "text-muted-foreground" : "text-blunder";

export function ReportCard({ report }: { report: Report }) {
  const og = grade(report.overall);
  return (
    <div className="space-y-6">
      <div className="grid gap-4 md:grid-cols-[1.2fr_2fr]">
        <div className="panel flex items-center gap-6 p-6">
          <div className={cn("font-display text-8xl leading-none", gradeColor(og))}>{og}</div>
          <div>
            <p className="font-mono text-xs uppercase tracking-widest text-muted-foreground">Overall</p>
            <p className="mt-1 text-3xl font-semibold">{report.accuracy.toFixed(1)}%</p>
            <p className="text-sm text-muted-foreground">avg accuracy</p>
            <p className="mt-2 font-mono text-sm">
              <span className="text-best">{report.record.w}W</span> · {report.record.d}D ·{" "}
              <span className="text-blunder">{report.record.l}L</span>
            </p>
          </div>
        </div>
        <div className="panel p-6">
          <p className="font-mono text-xs uppercase tracking-widest text-muted-foreground">Key takeaways</p>
          <ul className="mt-3 space-y-2">
            {report.insights.map((s, i) => (
              <li key={i} className="flex gap-3 text-sm">
                <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />
                {s}
              </li>
            ))}
          </ul>
        </div>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {report.categories.map((c) => {
          const g = grade(c.score);
          return (
            <div key={c.key} className="panel p-5">
              <div className="flex items-start justify-between">
                <p className="font-semibold">{c.title}</p>
                <span className={cn("font-display text-4xl leading-none", gradeColor(g))}>{g}</span>
              </div>
              <div className="mt-4 h-1.5 overflow-hidden rounded-full bg-secondary">
                <div className="h-full rounded-full bg-primary transition-all" style={{ width: `${c.score ?? 0}%` }} />
              </div>
              <p className="mt-3 text-xs text-muted-foreground">{c.detail}</p>
            </div>
          );
        })}
      </div>

      <div className="panel overflow-hidden">
        <p className="border-b border-border px-5 py-3 font-mono text-xs uppercase tracking-widest text-muted-foreground">Opening repertoire</p>
        <table className="w-full text-sm">
          <tbody>
            {report.openings.map((o) => (
              <tr key={o.name} className="border-b border-border/50 last:border-0">
                <td className="px-5 py-2.5">{o.name}</td>
                <td className="px-3 py-2.5 font-mono text-muted-foreground">{o.games}g</td>
                <td className="px-3 py-2.5 font-mono">
                  <span className="text-best">{o.w}</span>/{o.d}/<span className="text-blunder">{o.l}</span>
                </td>
                <td className="px-5 py-2.5 text-right font-mono">{o.accuracy.toFixed(0)}%</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export function GamesList({ games, onOpen }: { games: GameReview[]; onOpen: (id: string) => void }) {
  return (
    <div className="panel divide-y divide-border/60 overflow-hidden">
      {games.map((g) => {
        const opp = g.userColor === "w" ? g.black : g.white;
        const bl = g.moves.filter((m) => m.color === g.userColor && m.cls === "blunder").length;
        const mi = g.moves.filter((m) => m.color === g.userColor && m.cls === "mistake").length;
        return (
          <button key={g.id} onClick={() => onOpen(g.id)} className="flex w-full items-center gap-4 px-5 py-3 text-left hover:bg-accent/60">
            <span
              className={cn(
                "w-12 rounded px-2 py-1 text-center font-mono text-xs font-bold uppercase",
                g.result === "win" ? "bg-best/20 text-best" : g.result === "loss" ? "bg-blunder/20 text-blunder" : "bg-secondary text-muted-foreground",
              )}
            >
              {g.result}
            </span>
            <div className="min-w-0 flex-1">
              <p className="truncate font-semibold">
                vs {opp.name} <span className="font-mono text-xs text-muted-foreground">({opp.rating})</span>
              </p>
              <p className="truncate text-xs text-muted-foreground">
                {g.opening} · {g.timeClass} · {new Date(g.endTime * 1000).toLocaleDateString()}
              </p>
            </div>
            <span className="hidden font-mono text-xs sm:block">
              <span className="text-blunder">{bl}??</span> <span className="text-mistake">{mi}?</span>
            </span>
            <span className="w-14 text-right font-mono font-semibold">{g.accuracy.toFixed(0)}%</span>
          </button>
        );
      })}
    </div>
  );
}
