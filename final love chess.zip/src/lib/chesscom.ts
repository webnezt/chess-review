export type Side = { username: string; result: string; rating: number };
export type ChessComGame = {
  url: string;
  pgn: string;
  time_control: string;
  time_class: string;
  end_time: number;
  rules: string;
  white: Side;
  black: Side;
};

export async function fetchRecentGames(username: string, n: number): Promise<ChessComGame[]> {
  const r = await fetch(
    `https://api.chess.com/pub/player/${encodeURIComponent(username.toLowerCase())}/games/archives`,
  );
  if (r.status === 404) throw new Error("We couldn't find that chess.com username.");
  if (!r.ok) throw new Error("chess.com didn't respond. Try again in a moment.");
  const { archives } = (await r.json()) as { archives: string[] };
  const out: ChessComGame[] = [];
  for (let i = archives.length - 1; i >= 0 && out.length < n; i--) {
    const res = await fetch(archives[i]);
    if (!res.ok) continue;
    const data = (await res.json()) as { games?: ChessComGame[] };
    const list = (data.games ?? [])
      .filter((g) => g.rules === "chess" && g.pgn)
      .sort((a, b) => b.end_time - a.end_time);
    for (const g of list) {
      if (out.length >= n) break;
      out.push(g);
    }
  }
  return out;
}
