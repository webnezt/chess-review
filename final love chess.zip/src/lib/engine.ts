const SF_URL = "https://cdnjs.cloudflare.com/ajax/libs/stockfish.js/10.0.2/stockfish.js";

/** cp is always from White's point of view. */
export type Eval = { cp: number; mate: number | null; best: string | null };

export class Engine {
  private w: Worker;
  private queue: Promise<unknown> = Promise.resolve();

  constructor() {
    const blob = new Blob([`importScripts("${SF_URL}");`], { type: "application/javascript" });
    this.w = new Worker(URL.createObjectURL(blob));
    this.w.postMessage("uci");
    this.w.postMessage("setoption name Hash value 32");
  }

  analyze(fen: string, depth = 10): Promise<Eval> {
    const run = () =>
      new Promise<Eval>((resolve) => {
        const turn = fen.split(" ")[1];
        let cp = 0;
        let mate: number | null = null;
        let done = false;
        const finish = (best: string | null) => {
          if (done) return;
          done = true;
          clearTimeout(timer);
          this.w.removeEventListener("message", h);
          const s = turn === "w" ? 1 : -1;
          resolve({ cp: cp * s, mate: mate === null ? null : mate * s, best });
        };
        const timer = setTimeout(() => {
          this.w.postMessage("stop");
          setTimeout(() => finish(null), 300);
        }, 8000);
        const h = (e: MessageEvent) => {
          const line = String(e.data);
          if (line.startsWith("info") && line.includes(" score ")) {
            const m = line.match(/score (cp|mate) (-?\d+)/);
            if (m) {
              if (m[1] === "cp") {
                cp = +m[2];
                mate = null;
              } else {
                mate = +m[2];
                cp = mate > 0 ? 10000 : -10000;
              }
            }
          }
          if (line.startsWith("bestmove")) {
            const b = line.split(" ")[1];
            finish(b && b !== "(none)" ? b : null);
          }
        };
        this.w.addEventListener("message", h);
        this.w.postMessage("position fen " + fen);
        this.w.postMessage("go depth " + depth);
      });
    const p = this.queue.then(run);
    this.queue = p.catch(() => {});
    return p;
  }

  setSkill(level: number) {
    this.w.postMessage(`setoption name Skill Level value ${Math.max(0, Math.min(20, Math.round(level)))}`);
  }

  destroy() {
    this.w.terminate();
  }
}
