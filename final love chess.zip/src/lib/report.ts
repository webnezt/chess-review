import { avg, type GameReview, type MoveReview } from "./review";

export type Category = { key: string; title: string; score: number | null; detail: string };
export type Puzzle = {
  id: string;
  fen: string;
  best: string;
  bestSan: string;
  playedSan: string;
  color: "w" | "b";
  cls: "mistake" | "blunder";
  opponent: string;
  opening: string;
};

export const grade = (s: number | null) =>
  s == null ? "–" : s >= 90 ? "A" : s >= 80 ? "B" : s >= 70 ? "C" : s >= 60 ? "D" : "F";

const clamp = (v: number) => Math.max(0, Math.min(100, v));

export function buildReport(reviews: GameReview[]) {
  const um: (MoveReview & { g: GameReview })[] = reviews.flatMap((g) =>
    g.moves.filter((m) => m.color === g.userColor).map((m) => ({ ...m, g })),
  );
  const games = reviews.length || 1;
  const byPhase = (p: string) => um.filter((m) => m.phase === p);
  const blunders = um.filter((m) => m.cls === "blunder").length;
  const mistakes = um.filter((m) => m.cls === "mistake").length;

  const openingMoves = byPhase("opening");
  const mid = byPhase("middlegame");
  const end = byPhase("endgame");

  const opening = openingMoves.length ? avg(openingMoves.map((m) => m.accuracy)) : null;
  const tactics = mid.length ? clamp(avg(mid.map((m) => m.accuracy)) - (blunders / games) * 3) : null;
  const endgame = end.length >= 4 ? avg(end.map((m) => m.accuracy)) : null;

  const timed = um.filter((m) => m.clock != null && m.g.initialClock);
  const trouble = timed.filter((m) => m.clock! < Math.max(10, 0.1 * m.g.initialClock!));
  const troublePct = timed.length ? (trouble.length / timed.length) * 100 : 0;
  const troubleErrors = trouble.filter((m) => m.cls === "blunder" || m.cls === "mistake").length;
  const timeouts = reviews.filter((r) => r.result === "loss" && r.endReason === "timeout").length;
  const time = timed.length ? clamp(100 - troublePct * 1.5 - timeouts * 12 - troubleErrors * 4) : null;
  const avgOpeningTime = avg(openingMoves.filter((m) => m.timeSpent != null).map((m) => m.timeSpent!));
  const avgMidTime = avg(mid.filter((m) => m.timeSpent != null).map((m) => m.timeSpent!));

  const categories: Category[] = [
    {
      key: "opening",
      title: "Openings",
      score: opening,
      detail: `${opening?.toFixed(0) ?? "–"}% accuracy in the first 10 moves`,
    },
    {
      key: "tactics",
      title: "Tactics",
      score: tactics,
      detail: `${blunders} blunders, ${mistakes} mistakes across ${reviews.length} games`,
    },
    {
      key: "endgame",
      title: "Endgames",
      score: endgame,
      detail: endgame == null ? "Not enough endgame moves yet" : `${endgame.toFixed(0)}% accuracy once pieces came off`,
    },
    {
      key: "time",
      title: "Time",
      score: time,
      detail: timed.length
        ? `${troublePct.toFixed(0)}% of moves in time trouble · ${timeouts} lost on time`
        : "No clock data (daily games)",
    },
  ];

  const openingsMap = new Map<string, { name: string; w: number; d: number; l: number; acc: number[] }>();
  for (const r of reviews) {
    const e = openingsMap.get(r.opening) ?? { name: r.opening, w: 0, d: 0, l: 0, acc: [] };
    e[r.result === "win" ? "w" : r.result === "draw" ? "d" : "l"]++;
    e.acc.push(avg(r.moves.filter((m) => m.color === r.userColor && m.phase === "opening").map((m) => m.accuracy)));
    openingsMap.set(r.opening, e);
  }
  const openings = [...openingsMap.values()]
    .map((o) => ({ ...o, games: o.w + o.d + o.l, accuracy: avg(o.acc) }))
    .sort((a, b) => b.games - a.games);

  const insights: string[] = [];
  const phaseErr = (["opening", "middlegame", "endgame"] as const).map((p) => ({
    p,
    n: byPhase(p).filter((m) => m.cls === "blunder" || m.cls === "mistake").length,
  }));
  const worst = phaseErr.sort((a, b) => b.n - a.n)[0];
  if (worst?.n) insights.push(`Most of your serious errors (${worst.n}) happen in the ${worst.p}.`);
  if (troubleErrors) insights.push(`${troubleErrors} of your mistakes came with almost no time left on the clock.`);
  if (timed.length && avgOpeningTime > avgMidTime && avgMidTime > 0)
    insights.push(`You spend more time per move in the opening (${avgOpeningTime.toFixed(1)}s) than the middlegame (${avgMidTime.toFixed(1)}s) — save time for the hard part.`);
  const bad = openings.filter((o) => o.games >= 2 && o.l > o.w)[0];
  if (bad) insights.push(`${bad.name} is a weak spot: ${bad.w}W / ${bad.l}L. Worth studying.`);
  const good = openings.filter((o) => o.games >= 2 && o.w > o.l)[0];
  if (good) insights.push(`${good.name} is working for you: ${good.w}W / ${good.l}L.`);
  if (!insights.length) insights.push("Solid set of games — keep reviewing the moments where the eval swings.");

  const puzzles: Puzzle[] = um
    .filter((m) => (m.cls === "blunder" || m.cls === "mistake") && m.evalBefore.best && m.bestSan)
    .map((m) => ({
      id: m.g.id + m.ply,
      fen: m.fenBefore,
      best: m.evalBefore.best!,
      bestSan: m.bestSan!,
      playedSan: m.san,
      color: m.color,
      cls: m.cls as "mistake" | "blunder",
      opponent: m.g.userColor === "w" ? m.g.black.name : m.g.white.name,
      opening: m.g.opening,
    }));

  const scores = categories.map((c) => c.score).filter((s): s is number => s != null);
  return {
    categories,
    overall: scores.length ? avg(scores) : null,
    accuracy: avg(reviews.map((r) => r.accuracy)),
    record: {
      w: reviews.filter((r) => r.result === "win").length,
      d: reviews.filter((r) => r.result === "draw").length,
      l: reviews.filter((r) => r.result === "loss").length,
    },
    openings,
    insights,
    puzzles,
  };
}
