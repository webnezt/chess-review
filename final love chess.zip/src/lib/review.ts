import { Chess } from "chess.js";
import type { ChessComGame } from "./chesscom";
import type { Engine, Eval } from "./engine";

export const DEPTH = 10;

export type Cls = "best" | "good" | "inaccuracy" | "mistake" | "blunder";
export type Phase = "opening" | "middlegame" | "endgame";

export type MoveReview = {
  ply: number;
  san: string;
  uci: string;
  color: "w" | "b";
  fenBefore: string;
  fenAfter: string;
  evalBefore: Eval; // white POV
  evalAfter: Eval;
  bestSan: string | null;
  drop: number; // win% lost by mover
  accuracy: number;
  cls: Cls;
  phase: Phase;
  clock: number | null;
  timeSpent: number | null;
};

export type GameReview = {
  id: string;
  url: string;
  white: { name: string; rating: number };
  black: { name: string; rating: number };
  userColor: "w" | "b";
  result: "win" | "loss" | "draw";
  endReason: string;
  opening: string;
  timeClass: string;
  endTime: number;
  initialClock: number | null;
  moves: MoveReview[];
  accuracy: number;
};

export const winPct = (cp: number) => 50 + 50 * (2 / (1 + Math.exp(-0.00368208 * cp)) - 1);
const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));
export const avg = (xs: number[]) => (xs.length ? xs.reduce((s, x) => s + x, 0) / xs.length : 0);

const DRAWS = ["agreed", "repetition", "stalemate", "insufficient", "50move", "timevsinsufficient"];

function parseHeaders(pgn: string) {
  const h: Record<string, string> = {};
  for (const m of pgn.matchAll(/\[(\w+) "([^"]*)"\]/g)) h[m[1]] = m[2];
  return h;
}

function openingName(h: Record<string, string>) {
  const url = h.ECOUrl;
  if (!url) return h.ECO ? `ECO ${h.ECO}` : "Unknown opening";
  const slug = url.split("/").pop() ?? "";
  const words = slug.split("-").filter((w) => w && !/^\d/.test(w) && !/\d\./.test(w));
  return words.slice(0, 4).join(" ") || "Unknown opening";
}

function phaseOf(fen: string, ply: number): Phase {
  const pieces = (fen.split(" ")[0].match(/[nbrqNBRQ]/g) ?? []).length;
  if (pieces <= 6) return "endgame";
  if (ply < 20) return "opening";
  return "middlegame";
}

export async function reviewGame(
  g: ChessComGame,
  username: string,
  eng: Engine,
  onProgress: (done: number, total: number) => void,
): Promise<GameReview | null> {
  const chess = new Chess();
  try {
    chess.loadPgn(g.pgn);
  } catch {
    return null;
  }
  const hist = chess.history({ verbose: true });
  if (hist.length < 2) return null;
  const h = parseHeaders(g.pgn);
  const clocks = [...g.pgn.matchAll(/\[%clk (\d+):(\d+):(\d+(?:\.\d+)?)\]/g)].map(
    (m) => +m[1] * 3600 + +m[2] * 60 + +m[3],
  );
  const tc = g.time_control.includes("/") ? null : g.time_control.split("+").map(Number);
  const base = tc ? tc[0] : null;
  const inc = tc ? (tc[1] ?? 0) : 0;

  const fens = [hist[0].before, ...hist.map((m) => m.after)];
  const evals: Eval[] = [];
  for (let i = 0; i < fens.length; i++) {
    const c = new Chess(fens[i]);
    if (c.isCheckmate()) evals.push({ cp: c.turn() === "w" ? -10000 : 10000, mate: 0, best: null });
    else if (c.isGameOver()) evals.push({ cp: 0, mate: null, best: null });
    else evals.push(await eng.analyze(fens[i], DEPTH));
    onProgress(i + 1, fens.length);
  }

  const userColor = g.white.username.toLowerCase() === username.toLowerCase() ? "w" : "b";
  const moves: MoveReview[] = hist.map((m, i) => {
    const s = m.color === "w" ? 1 : -1;
    const before = clamp(evals[i].cp * s, -1500, 1500);
    const after = clamp(evals[i + 1].cp * s, -1500, 1500);
    const drop = Math.max(0, winPct(before) - winPct(after));
    const accuracy = clamp(103.1668 * Math.exp(-0.04354 * drop) - 3.1669, 0, 100);
    const uci = m.from + m.to + (m.promotion ?? "");
    const best = evals[i].best;
    let bestSan: string | null = null;
    if (best) {
      try {
        bestSan = new Chess(m.before).move({ from: best.slice(0, 2), to: best.slice(2, 4), promotion: best[4] || "q" }).san;
      } catch {
        bestSan = null;
      }
    }
    const cls: Cls =
      uci === best ? "best" : drop >= 20 ? "blunder" : drop >= 10 ? "mistake" : drop >= 5 ? "inaccuracy" : "good";
    const clock = clocks[i] ?? null;
    const prev = i >= 2 ? clocks[i - 2] : base;
    const timeSpent = clock != null && prev != null ? Math.max(0, prev - clock + (i >= 2 ? inc : 0)) : null;
    return {
      ply: i,
      san: m.san,
      uci,
      color: m.color,
      fenBefore: m.before,
      fenAfter: m.after,
      evalBefore: evals[i],
      evalAfter: evals[i + 1],
      bestSan,
      drop,
      accuracy,
      cls,
      phase: phaseOf(m.before, i),
      clock,
      timeSpent,
    };
  });

  const us = userColor === "w" ? g.white : g.black;
  const them = userColor === "w" ? g.black : g.white;
  const result = us.result === "win" ? "win" : DRAWS.includes(us.result) ? "draw" : "loss";

  return {
    id: g.url,
    url: g.url,
    white: { name: g.white.username, rating: g.white.rating },
    black: { name: g.black.username, rating: g.black.rating },
    userColor,
    result,
    endReason: result === "loss" ? us.result : result === "win" ? them.result : us.result,
    opening: openingName(h),
    timeClass: g.time_class,
    endTime: g.end_time,
    initialClock: base,
    moves,
    accuracy: avg(moves.filter((m) => m.color === userColor).map((m) => m.accuracy)),
  };
}
