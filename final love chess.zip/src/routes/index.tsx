import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState, type FormEvent } from "react";
import { Search, Loader2 } from "lucide-react";
import { fetchRecentGames } from "@/lib/chesscom";
import { Engine } from "@/lib/engine";
import { reviewGame, type GameReview } from "@/lib/review";
import { buildReport } from "@/lib/report";
import { ReportCard, GamesList } from "@/components/review/ReportCard";
import { GameViewer } from "@/components/review/GameViewer";
import { Puzzles } from "@/components/review/Puzzles";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Blundercheck — Review your chess.com games" },
      { name: "description", content: "Enter your chess.com username to get engine analysis, a report card, and puzzles from your own blunders." },
      { property: "og:title", content: "Blundercheck — Review your chess.com games" },
      { property: "og:description", content: "Engine analysis, report card and puzzles built from your last 10 chess.com games." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

type Tab = "report" | "games" | "puzzles";

function Index() {
  const [username, setUsername] = useState("");
  const [status, setStatus] = useState<"idle" | "fetching" | "analyzing" | "done" | "error">("idle");
  const [error, setError] = useState("");
  const [reviews, setReviews] = useState<GameReview[]>([]);
  const [progress, setProgress] = useState({ game: 0, total: 0, ply: 0, plies: 0 });
  const [tab, setTab] = useState<Tab>("report");
  const [openId, setOpenId] = useState<string | null>(null);
  const engineRef = useRef<Engine | null>(null);
  const runId = useRef(0);

  useEffect(() => () => engineRef.current?.destroy(), []);

  async function start(e: FormEvent) {
    e.preventDefault();
    const u = username.trim();
    if (!u) return;
    const id = ++runId.current;
    setStatus("fetching");
    setReviews([]);
    setOpenId(null);
    setTab("report");
    setError("");
    try {
      const games = await fetchRecentGames(u, 10);
      if (!games.length) throw new Error("No recent games found for that username.");
      engineRef.current?.destroy();
      const eng = new Engine();
      engineRef.current = eng;
      setStatus("analyzing");
      for (let i = 0; i < games.length; i++) {
        if (runId.current !== id) return;
        setProgress({ game: i + 1, total: games.length, ply: 0, plies: 0 });
        const r = await reviewGame(games[i], u, eng, (ply, plies) => {
          if (runId.current === id) setProgress((p) => ({ ...p, ply, plies }));
        });
        if (runId.current !== id) return;
        if (r) setReviews((prev) => [...prev, r]);
      }
      setStatus("done");
    } catch (err) {
      if (runId.current !== id) return;
      setError(err instanceof Error ? err.message : "Something went wrong.");
      setStatus("error");
    }
  }

  const report = useMemo(() => (reviews.length ? buildReport(reviews) : null), [reviews]);
  const open = reviews.find((r) => r.id === openId);
  const pct = progress.total
    ? ((progress.game - 1 + (progress.plies ? progress.ply / progress.plies : 0)) / progress.total) * 100
    : 0;
  const hasData = reviews.length > 0;

  return (
    <div className="min-h-screen bg-background bg-grid">
      <header className="border-b border-border/60 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
          <div className="flex items-center gap-2 font-display text-xl">
            <span className="text-primary">♞</span> Blundercheck
          </div>
          <div className="flex items-center gap-4">
          <Link to="/play" className="text-sm text-muted-foreground hover:text-foreground">Play Stockfish</Link>
          {hasData && <SearchForm username={username} setUsername={setUsername} onSubmit={start} busy={status === "fetching" || status === "analyzing"} compact />}
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-6 py-10">
        {!hasData && (
          <section className="mx-auto max-w-2xl py-16 text-center">
            <p className="font-mono text-xs uppercase tracking-[0.3em] text-primary">Stockfish · in your browser</p>
            <h1 className="mt-4 font-display text-5xl leading-tight md:text-6xl">
              Find out <em className="text-primary">why</em> you lost.
            </h1>
            <p className="mx-auto mt-4 max-w-lg text-muted-foreground">
              Enter your chess.com username. We'll analyze your last 10 games and grade your openings, tactics, endgames and clock handling.
            </p>
            <div className="mt-8">
              <SearchForm username={username} setUsername={setUsername} onSubmit={start} busy={status === "fetching" || status === "analyzing"} />
            </div>
            {status === "error" && <p className="mt-4 text-sm text-blunder">{error}</p>}
            {status === "fetching" && <p className="mt-4 text-sm text-muted-foreground">Fetching games from chess.com…</p>}
            {status === "analyzing" && <Progress pct={pct} progress={progress} />}
          </section>
        )}

        {hasData && report && (
          <div className="space-y-6">
            {status === "analyzing" && <Progress pct={pct} progress={progress} />}
            {status === "error" && <p className="text-sm text-blunder">{error}</p>}
            {!open && (
              <nav className="flex gap-1 rounded-lg bg-secondary p-1 sm:w-fit">
                {(
                  [
                    ["report", "Report card"],
                    ["games", `Games (${reviews.length})`],
                    ["puzzles", `Puzzles (${report.puzzles.length})`],
                  ] as [Tab, string][]
                ).map(([k, l]) => (
                  <button
                    key={k}
                    onClick={() => setTab(k)}
                    className={cn("flex-1 rounded-md px-4 py-2 text-sm transition-colors", tab === k ? "bg-card text-foreground shadow" : "text-muted-foreground hover:text-foreground")}
                  >
                    {l}
                  </button>
                ))}
              </nav>
            )}
            {open ? (
              <GameViewer key={open.id} game={open} onBack={() => setOpenId(null)} />
            ) : tab === "report" ? (
              <ReportCard report={report} />
            ) : tab === "games" ? (
              <GamesList games={reviews} onOpen={setOpenId} />
            ) : (
              <Puzzles puzzles={report.puzzles} />
            )}
          </div>
        )}
      </main>
    </div>
  );
}

function SearchForm({
  username,
  setUsername,
  onSubmit,
  busy,
  compact,
}: {
  username: string;
  setUsername: (s: string) => void;
  onSubmit: (e: FormEvent) => void;
  busy: boolean;
  compact?: boolean;
}) {
  return (
    <form onSubmit={onSubmit} className={cn("flex gap-2", compact ? "w-64" : "mx-auto max-w-md")}>
      <div className="relative flex-1">
        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <input
          value={username}
          onChange={(e) => setUsername(e.target.value)}
          placeholder="chess.com username"
          className={cn("w-full rounded-md border border-input bg-card pl-9 pr-3 outline-none focus:ring-2 focus:ring-ring", compact ? "py-1.5 text-sm" : "py-3")}
        />
      </div>
      <button
        disabled={busy || !username.trim()}
        className={cn("inline-flex items-center gap-2 rounded-md bg-primary font-semibold text-primary-foreground shadow-glow hover:opacity-90 disabled:opacity-50", compact ? "px-3 text-sm" : "px-5")}
      >
        {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : "Review"}
      </button>
    </form>
  );
}

function Progress({ pct, progress }: { pct: number; progress: { game: number; total: number; ply: number; plies: number } }) {
  return (
    <div className="panel mx-auto mt-6 max-w-md p-4 text-left">
      <div className="flex justify-between font-mono text-xs text-muted-foreground">
        <span>Analyzing game {progress.game} of {progress.total}</span>
        <span>{pct.toFixed(0)}%</span>
      </div>
      <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-secondary">
        <div className="h-full bg-primary transition-all" style={{ width: `${pct}%` }} />
      </div>
    </div>
  );
}
