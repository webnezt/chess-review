import { createFileRoute, Link } from "@tanstack/react-router";
import { Chess } from "chess.js";
import { useEffect, useRef, useState } from "react";
import { Loader2 } from "lucide-react";
import { Engine } from "@/lib/engine";
import { Board } from "@/components/review/Board";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/play")({
  head: () => ({
    meta: [
      { title: "Play Stockfish at any rating — Blundercheck" },
      { name: "description", content: "Play Stockfish set to your level, from 400 to 2800 Elo." },
      { property: "og:title", content: "Play Stockfish at any rating — Blundercheck" },
      { property: "og:description", content: "Pick a rating and play a game against Stockfish in your browser." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Play,
});

const PRESETS = [400, 800, 1000, 1200, 1500, 1800, 2200, 2800];

/** Map a target rating to engine strength settings. */
function strength(elo: number) {
  const t = (elo - 400) / 2400;
  return {
    skill: Math.round(t * 20),
    depth: Math.max(1, Math.min(14, Math.round(1 + t * 13))),
    randomChance: elo < 1400 ? (1400 - elo) / 2500 : 0,
  };
}

function Play() {
  const [elo, setElo] = useState(1200);
  const [color, setColor] = useState<"w" | "b">("w");
  const [game, setGame] = useState<{ fen: string; history: string[]; last: string | null; elo: number; color: "w" | "b" } | null>(null);
  const [thinking, setThinking] = useState(false);
  const [resigned, setResigned] = useState(false);
  const eng = useRef<Engine | null>(null);

  useEffect(() => () => eng.current?.destroy(), []);

  const start = () => {
    eng.current?.destroy();
    const e = new Engine();
    e.setSkill(strength(elo).skill);
    eng.current = e;
    setResigned(false);
    setThinking(false);
    setGame({ fen: new Chess().fen(), history: [], last: null, elo, color });
  };

  const chess = game ? new Chess(game.fen) : null;
  const over = !!chess && (chess.isGameOver() || resigned);

  // Engine moves when it's its turn.
  useEffect(() => {
    if (!game || !eng.current || resigned) return;
    const c = new Chess(game.fen);
    if (c.isGameOver() || c.turn() === game.color) return;
    let cancelled = false;
    setThinking(true);
    const s = strength(game.elo);
    const run = async () => {
      let uci: string | null = null;
      const moves = c.moves({ verbose: true });
      if (Math.random() < s.randomChance) {
        const m = moves[Math.floor(Math.random() * moves.length)];
        uci = m.from + m.to + (m.promotion ?? "");
        await new Promise((r) => setTimeout(r, 500));
      } else {
        uci = (await eng.current!.analyze(game.fen, s.depth)).best;
      }
      if (cancelled || !uci) return;
      const m = c.move({ from: uci.slice(0, 2), to: uci.slice(2, 4), promotion: uci[4] || "q" });
      setGame((g) => (g ? { ...g, fen: c.fen(), history: [...g.history, m.san], last: uci } : g));
      setThinking(false);
    };
    run();
    return () => {
      cancelled = true;
    };
  }, [game, resigned]);

  const onMove = (from: string, to: string) => {
    if (!game || !chess || over || chess.turn() !== game.color) return;
    try {
      const m = chess.move({ from, to, promotion: "q" });
      setGame({ ...game, fen: chess.fen(), history: [...game.history, m.san], last: from + to });
    } catch {
      /* illegal */
    }
  };

  let status = "";
  if (chess && game) {
    if (resigned) status = "You resigned.";
    else if (chess.isCheckmate()) status = chess.turn() === game.color ? "Checkmate — Stockfish wins." : "Checkmate — you win!";
    else if (chess.isDraw() || chess.isStalemate()) status = "Draw.";
    else if (thinking) status = "Stockfish is thinking…";
    else status = chess.inCheck() ? "Your move — you're in check!" : "Your move.";
  }

  return (
    <div className="min-h-screen bg-background bg-grid">
      <header className="border-b border-border/60">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
          <Link to="/" className="flex items-center gap-2 font-display text-xl">
            <span className="text-primary">♞</span> Blundercheck
          </Link>
          <Link to="/" className="text-sm text-muted-foreground hover:text-foreground">Review games</Link>
        </div>
      </header>
      <main className="mx-auto grid max-w-6xl gap-8 px-6 py-10 lg:grid-cols-[minmax(0,560px)_1fr]">
        <div className="space-y-2">
          <div className="flex justify-between px-1 text-sm">
            <span className="font-semibold">Stockfish</span>
            <span className="font-mono text-muted-foreground">{game?.elo ?? elo}</span>
          </div>
          <Board
            fen={game?.fen ?? new Chess().fen()}
            orientation={game?.color ?? color}
            lastMove={game?.last}
            onMove={game && !over && !thinking ? onMove : undefined}
          />
          <div className="flex justify-between px-1 text-sm">
            <span className="font-semibold">You</span>
          </div>
        </div>

        <div className="space-y-4">
          <div className="panel space-y-5 p-5">
            <div>
              <p className="font-mono text-xs uppercase tracking-widest text-muted-foreground">Stockfish rating</p>
              <p className="mt-1 font-display text-5xl text-primary">{elo}</p>
              <input
                type="range"
                min={400}
                max={2800}
                step={50}
                value={elo}
                onChange={(e) => setElo(+e.target.value)}
                className="mt-3 w-full accent-primary"
              />
              <div className="mt-3 flex flex-wrap gap-1.5">
                {PRESETS.map((p) => (
                  <button
                    key={p}
                    onClick={() => setElo(p)}
                    className={cn("rounded-md px-2.5 py-1 font-mono text-xs", elo === p ? "bg-primary text-primary-foreground" : "bg-secondary hover:bg-accent")}
                  >
                    {p}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <p className="font-mono text-xs uppercase tracking-widest text-muted-foreground">You play</p>
              <div className="mt-2 flex gap-2">
                {(["w", "b"] as const).map((c) => (
                  <button
                    key={c}
                    onClick={() => setColor(c)}
                    className={cn("flex-1 rounded-md py-2 text-sm", color === c ? "bg-primary text-primary-foreground" : "bg-secondary hover:bg-accent")}
                  >
                    {c === "w" ? "White" : "Black"}
                  </button>
                ))}
              </div>
            </div>
            <button onClick={start} className="w-full rounded-md bg-primary py-3 font-semibold text-primary-foreground shadow-glow hover:opacity-90">
              {game ? "New game" : "Start game"}
            </button>
            {game && game.elo !== elo && (
              <p className="text-xs text-muted-foreground">The new rating applies when you start a new game.</p>
            )}
          </div>

          {game && (
            <div className="panel p-5">
              <p className="inline-flex items-center gap-2 font-semibold">
                {thinking && !over && <Loader2 className="h-4 w-4 animate-spin" />}
                {status}
              </p>
              <p className="mt-3 max-h-48 overflow-y-auto font-mono text-sm leading-7 text-muted-foreground">
                {game.history.map((m, i) => (
                  <span key={i}>
                    {i % 2 === 0 && <span className="mr-1">{i / 2 + 1}.</span>}
                    <span className="mr-2 text-foreground">{m}</span>
                  </span>
                ))}
              </p>
              {!over && (
                <button onClick={() => setResigned(true)} className="mt-3 rounded-md bg-secondary px-3 py-1.5 text-sm hover:bg-accent">
                  Resign
                </button>
              )}
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
